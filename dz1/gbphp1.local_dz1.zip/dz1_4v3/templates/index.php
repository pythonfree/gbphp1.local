<!DOCTYPE html>
<html>
<head>
    <title>{{title}}</title>
    <meta charset="{{charset}}"
</head>
<body>
<h1>{{h1}}</h1>
{{content}}
<br><br>
<img src="{{imgSrc}}" alt="Тут можете поместить картинку">
<br><br>
<br><br>
<b>Просто пример жирного текста</b>
<br><br>
{{cr}}
</body>
</html>