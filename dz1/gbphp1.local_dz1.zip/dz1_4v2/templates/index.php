<!DOCTYPE html>
<html>
<head>
    <title><?php echo $title; ?></title>
    <meta charset="<?php echo $charset; ?>"
</head>
<body>
<h1><?php echo $h1; ?></h1>
<?php echo $content; ?>
<br><br>
<img src="<?php echo $imgSrc; ?>" alt="Тут можете поместить картинку">
<br><br>
<br><br>
<b>Просто пример жирного текста</b>
<br><br>
<?php echo $cr; ?>
</body>
</html>